1.Xcode插件的安装路径(可以在这里删除内容来卸载插件)
(aplle是用户名)
/Users/aplle/Library/Application Support/Developer/Shared/Xcode/Plug-ins

