// 
//  Person.m
//  HelloWorld
//
//  Created by Erica Sadun on 8/25/09.
//  Copyright 2009 Up To No Good, Inc.. All rights reserved.
//

#import "Person.h"

#import "Department.h"

@implementation Person 

@dynamic birthday;
@dynamic name;
@dynamic department;

@end
