// 
//  Department.m
//  HelloWorld
//
//  Created by Erica Sadun on 8/25/09.
//  Copyright 2009 Up To No Good, Inc.. All rights reserved.
//

#import "Department.h"


@implementation Department 

@dynamic groupName;
@dynamic manager;
@dynamic members;

@end
