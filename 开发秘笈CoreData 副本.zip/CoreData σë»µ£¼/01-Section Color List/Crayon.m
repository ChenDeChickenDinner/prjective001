// 
//  Crayon.m
//  HelloWorld
//
//  Created by Erica Sadun on 8/24/09.
//  Copyright 2009 Up To No Good, Inc.. All rights reserved.
//

#import "Crayon.h"


@implementation Crayon 

@dynamic name;
@dynamic section;
@dynamic color;

@end
