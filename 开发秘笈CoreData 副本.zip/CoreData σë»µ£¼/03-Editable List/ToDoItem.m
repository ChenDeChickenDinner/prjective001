// 
//  ToDoItem.m
//  HelloWorld
//
//  Created by Erica Sadun on 8/24/09.
//  Copyright 2009 Up To No Good, Inc.. All rights reserved.
//

#import "ToDoItem.h"


@implementation ToDoItem 

@dynamic action;
@dynamic sectionName;

@end
