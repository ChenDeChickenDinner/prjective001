//
//  main.m
//  NO4
//
//  Created by xs on 2018/10/11.
//  Copyright © 2018年 Touker. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}


/**
 构造数据类型-结构体
 */
void test1(){
  
}
