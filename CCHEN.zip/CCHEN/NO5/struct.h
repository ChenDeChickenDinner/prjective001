//
//  struct.h
//  NO5
//
//  Created by xs on 2018/10/12.
//  Copyright © 2018年 Touker. All rights reserved.
//

#ifndef struct_h
#define struct_h

#include <stdio.h>

#endif /* struct_h */

struct person{
    int age;
};

